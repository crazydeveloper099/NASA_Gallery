package com.example.exercise_app;

import android.app.Application;

public class MyApplication extends Application {
}
