package com.example.exercise_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;

import com.example.exercise_app.Adapters.image_grid_view_adapter;

public class MainActivity extends AppCompatActivity {
    GridView image_grid_view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        image_grid_view=findViewById(R.id.image_grid_view);
        image_grid_view.setAdapter(new image_grid_view_adapter(this));

        image_grid_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Intent intent=new Intent(getApplicationContext(),Image_detail_screen.class);
                intent.putExtra("id",position);
                startActivity(intent);
            }
        });
    }
}
