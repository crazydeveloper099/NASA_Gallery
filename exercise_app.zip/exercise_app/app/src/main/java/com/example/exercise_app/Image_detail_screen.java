package com.example.exercise_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import com.example.exercise_app.Adapters.image_grid_view_adapter;

public class Image_detail_screen extends AppCompatActivity {
ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_detail_screen);

        getSupportActionBar().hide();
        getSupportActionBar().setTitle("Full Image");

        imageView=findViewById(R.id.full_screen_image);

        Intent intent=getIntent();
        int position=intent.getExtras().getInt("id");

        image_grid_view_adapter grid_view_adapter=new image_grid_view_adapter(this);

        imageView.setImageResource(grid_view_adapter.image_array[position]);
    }
}
